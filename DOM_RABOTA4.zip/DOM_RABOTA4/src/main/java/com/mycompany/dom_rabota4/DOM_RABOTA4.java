package com.mycompany.dom_rabota4;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author User
 */
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class DOM_RABOTA4 {

    private static final List<Passport> passports = new ArrayList<>();

    public static void main(String[] args) {
        int a;
        System.out.println("Трохин Александр Андреевич");
        System.out.println("Группа РИБО-01-21, Вариант 4");

        passports.add(new Passport("123456", "Иванов Иван Иванович", "директор", true));
        passports.add(new Passport("478961", "Яковлев Даниил Александрович", "дворник", false));
        passports.add(new Passport("456321", "Борисов Антон Валерьевич", "повар", true));
        passports.add(new Passport("988666", "Лукашенко Дмитрий Викторович", "сантехник", false));
        passports.add(new Passport("456321", "Матвеенко Лидия Алексеевна", "секретарь", true));
        
        while (true) {
            while (true) {
                System.out.println();
                System.out.println("Выберите дейтсвие:");
                System.out.println("1 - Добавить новый пропуск");
                System.out.println("2 - Показать все пропуски");
                try {
                    a = Integer.parseInt(scan());
                    if (a != 1 && a != 2) {
                        System.out.println("Необходимо ввести целое число 1 или 2");
                        continue;
                    }
                    break;
                } catch (NumberFormatException e) {
                    System.out.println("Необходимо ввести целое число 1 или 2");
                }
            }
            System.out.println();
            switch (a) {
                case 1:
                    addPassport(createPassport());
                    break;
                case 2:
                    showPassports();
                    break;
            }
        }
    }

    public static Passport createPassport() {
        String number, fullName, post;
        boolean access;
        int a;
        while (true) {
            System.out.println();
            System.out.println("Введите номер пропуска:");
            number = scan();
            if (number.isEmpty() || number.isBlank()) {
                System.out.println("Поле \"Номер\" должно быть заполнено.");
                continue;
            }
            break;
        }
        while (true) {
            System.out.println();
            System.out.println("Введите ФИО сотрудника:");
            fullName = scan();
            if (fullName.isEmpty() || fullName.isBlank()) {
                System.out.println("Поле \"ФИО\" должно быть заполнено.");
                continue;
            }
            break;
        }
        while (true) {
            System.out.println();
            System.out.println("Введите должность сотрудника:");
            post = scan();
            if (post.isEmpty() || post.isBlank()) {
                System.out.println("Поле \"Должность\" должно быть заполнено.");
                continue;
            }
            break;
        }
        while (true) {
            System.out.println();
            System.out.println("Есть ли доступ на территорию у сотрудника?(Введите число 1 или 2):");
            System.out.println("1 - Да");
            System.out.println("2 - Нет");
            try {
                a = Integer.parseInt(scan());
                if (a != 1 && a != 2) {
                    System.out.println("Необходимо ввести целое число 1 или 2");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("Необходимо ввести целое число 1 или 2");
            }
        }
        access = a == 1;
        return new Passport(number, fullName, post, access);
    }

    public static void addPassport(Passport passport) {
        System.out.println();
        Passport oldPassport = null;
        for (Passport pass : passports) {
            if (pass.getNumber().equals(passport.getNumber())) {
                if (pass.getFullName().equals(passport.getFullName())) {
                    System.out.println("Пропуск с таким номером и ФИО уже существует.");
                    return;
                }
                oldPassport = pass;
                break;
            }
        }
        if (oldPassport != null) {
            passports.remove(oldPassport);
        }
        passports.add(passport);
        System.out.println("Пропуск успешно добавлен!");
    }

    public static void showPassports() {
        System.out.println();
        passports.sort(Comparator.comparing(Passport::getFullName));
        for (Passport passport : passports) {
            System.out.println(passport);
        }
        System.out.println();
        passports.sort(Comparator.comparing(Passport::getNumber));
        for (Passport passport : passports) {
            System.out.println(passport);
        }
    }

    public static String scan() {
        return new Scanner(System.in).nextLine();
    }
}