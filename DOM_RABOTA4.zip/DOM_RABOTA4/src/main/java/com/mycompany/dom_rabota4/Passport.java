package com.mycompany.dom_rabota4;

public class Passport {
    private String number;
    private String fullName;
    private String post;
    private boolean accessToTerritory;

    public Passport(String number, String fullName, String post, boolean accessToTerritory) {
        this.number = number;
        this.fullName = fullName;
        this.post = post;
        this.accessToTerritory = accessToTerritory;
    }

    @Override
    public String toString() {
        return fullName + ", " + number + ", " + post + ", " + accessToTerritory;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public boolean isAccessToTerritory() {
        return accessToTerritory;
    }

    public void setAccessToTerritory(boolean accessToTerritory) {
        this.accessToTerritory = accessToTerritory;
    }
}
